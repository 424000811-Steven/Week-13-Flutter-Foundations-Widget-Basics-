import 'package:flutter_test/flutter_test.dart';
import 'package:week13_static_screen/main.dart';

void main() {
  testWidgets('Messages board renders expected sections', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MessagesBoardApp());

    expect(find.text('Messages'), findsOneWidget);
    expect(find.text('From:'), findsOneWidget);
    expect(find.text('To:'), findsOneWidget);
    expect(find.text('Compose Message:'), findsOneWidget);
    expect(find.text('SEND'), findsOneWidget);
  });
}
